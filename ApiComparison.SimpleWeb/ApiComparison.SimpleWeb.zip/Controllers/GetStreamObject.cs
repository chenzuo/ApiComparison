﻿using System.IO;
using Simple.Web;
using Simple.Web.Behaviors;

namespace ApiComparison.SimpleWeb.Controllers
{
    [UriTemplate("/objects/stream")]
    public class GetStreamObject : IGet, IOutputStream
    {
        public Status Get()
        {
            Output = new MemoryStream();
            ContentType = "text/plain";

            return Status.OK;
        }

        public string ContentType { get; private set; }
        public string ContentDisposition { get; private set; }
        public Stream Output { get; private set; }
    }
}