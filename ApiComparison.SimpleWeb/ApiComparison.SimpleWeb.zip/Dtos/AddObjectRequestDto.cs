﻿namespace ApiComparison.SimpleWeb.Dtos
{
    public class AddObjectRequestDto
    {
        public string Name { get; set; }
    }
}