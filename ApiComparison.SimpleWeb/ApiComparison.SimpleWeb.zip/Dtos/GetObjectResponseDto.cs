﻿using System;

namespace ApiComparison.SimpleWeb.Dtos
{
    public class GetObjectResponseDto
    {
        public int Id { get; set; }
    }
}